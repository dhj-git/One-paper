#from gettext import npgettext
import os
import argparse
import torch
import numpy as np
import random
from tqdm import tqdm
from logger import logger
from data import load_data,EntDataset #,word2vec,tokenize_word,sent2vec
from model import SpanExtractAndClassification,multilabel_categorical_crossentropy,loss_fun,MetricsCalculator
from  PGD import FGM
# from stanfordNLp import stanfordNLPProcess
import torch.nn.functional as F

from torch.utils.data import TensorDataset, DataLoader,RandomSampler
from transformers import AutoTokenizer,AutoModel,AutoConfig,AdamW,get_linear_schedule_with_warmup



def read_train_data(args,tokenizer):
    train_path = os.path.join(args.data_dir, args.train_file)
    data = load_data(train_path)
    # print(data)
    f = open("/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/data/camera/train_dep_out.txt",'r')
    out= []
    for i in f:
        dep_out = list(eval(i))
        out.append(dep_out)
    # print(out)
    # print(f)
    train_features = EntDataset(data,tokenizer,args.max_len,out)
    # print(len(train_features))
    num_train_steps = int(len(train_features) / args.batch_size / args.gradient_accumulation_steps * args.epochs)
    
    train_dataloader = DataLoader(train_features, batch_size=args.batch_size,collate_fn=train_features.collate, shuffle=False)
    return train_dataloader ,num_train_steps

def read_test_data(args,tokenizer):
    test_path = os.path.join(args.data_dir, args.test_file)
    data = load_data(test_path)
    f = open("/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/data/camera/test_dep_out.txt",'r')
    out= []
    for i in f:
        dep_out = list(eval(i))
        out.append(dep_out)
    test_features = EntDataset(data,tokenizer,args.max_len,out)
    
    # test_sampler = RandomSampler(test_features)
    test_dataloader = DataLoader(test_features, batch_size=args.batch_size,collate_fn=test_features.collate, shuffle=True)
    return test_dataloader

def set_optimizer( model, train_steps=None):
    param_optimizer = list(model.named_parameters())
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]

    optimizer = AdamW(optimizer_grouped_parameters,lr=2e-5,eps =1e-8)
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=0, num_training_steps=train_steps)  
                         
    return optimizer,scheduler

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", default='/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/data/', type=str)
    parser.add_argument("--train_file", default='train.txt', type=str)
    parser.add_argument("--test_file", default='test.txt', type=str)
    parser.add_argument("--max_len", default=120, type=int)
    parser.add_argument("--batch_size", default=32, type=int)
    parser.add_argument("--gradient_accumulation_steps", default=1, type=int)
    parser.add_argument("--epochs", default=50, type=int)
    parser.add_argument("--pretrain_model",default="ernie-gram", type=str)
    args = parser.parse_args()

    device = torch.device("cuda:3") #GPU
    

    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)

    config = AutoConfig.from_pretrained(args.pretrain_model)
    
    tokenizer = AutoTokenizer.from_pretrained(args.pretrain_model, do_basic_tokenize=True, never_split=[])
    # tokenizer = BertTokenizer.from_pretrained("bert-base-uncased", do_basic_tokenize=True, never_split=[])
    torch.cuda.empty_cache()
    model = SpanExtractAndClassification.from_pretrained(args.pretrain_model)
    model.to(device)

    train_dataloader ,num_train_steps= read_train_data(args,tokenizer)
    test_dataloader = read_test_data(args,tokenizer)
    optimizer,scheduler = set_optimizer(model,train_steps=num_train_steps)

    metrics = MetricsCalculator()
    max_f, max_recall = 0.0, 0.0
    fgm = FGM(model)

    for eo in range(args.epochs):
        print("*******************************epoch**********************:",eo)
        total_loss, total_f1 = 0., 0.
        for idx, batch in enumerate(train_dataloader):
            text,input_ids, attention_mask, segment_ids, labels,adjacency_matrix = batch#,batch_word_emd
  
            # batch_word_emd = batch_word_emd.to(device)
            adjacency_matrix = adjacency_matrix.to(device)
            input_ids, attention_mask, segment_ids, labels = input_ids.to(device), attention_mask.to(device), segment_ids.to(device), labels.to(device)
            
            # print(batch_adjacency_matrix.shape)
            
            loss,logits = model(input_ids, attention_mask, segment_ids,adjacency_matrix,train=True,labels=labels)#batch_word_emd,
            # loss = loss_fun(logits, labels)
            loss.backward()
            ####对抗训练#####
            # fgm.attack() # 在embedding上添加对抗扰动
            # loss_adv,logits = model(input_ids, attention_mask, segment_ids,adjacency_matrix,train=True,labels=labels)#batch_word_emd,
            # loss_adv.backward() # 反向传播，并在正常的grad基础上，累加对抗训练的梯度
            # fgm.restore() # 恢复embedding参数

            #################对抗end
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1)
            optimizer.step()
            scheduler.step()
            # optimizer.zero_grad()
            # model.zero_grad()###这一句也是对抗 
            # print(labels)
            sample_f1 = metrics.get_sample_f1(logits, labels)
            total_loss+=loss.item()
            total_f1 += sample_f1.item()
            avg_loss = total_loss / (idx + 1)
            avg_f1 = total_f1 / (idx + 1)
            if idx % 10 == 0:
                logger.info("trian_loss:%f\t train_f1:%f"%(avg_loss, avg_f1))
        with torch.no_grad():
            total_f1_, total_precision_, total_recall_ = 0., 0., 0.
            model.eval()
            for batch in tqdm(test_dataloader):
                text,input_ids, attention_mask, segment_ids, labels ,adjacency_matrix= batch#,batch_word_emd
                # seg_word = []
                # for senten in text:
                #     seg = tokenize_word(senten)
                #     seg_word.append(seg)
                # # print(seg_word)
                # # print(text)
                # word_emd1 = sent2vec(seg_word)
                # batch_word_emd = batch_word_emd.to(device)
                adjacency_matrix = adjacency_matrix.to(device)
                input_ids, attention_mask, segment_ids, labels = input_ids.to(device), attention_mask.to(device), segment_ids.to(device), labels.to(device)
                logits = model(input_ids, attention_mask, segment_ids,adjacency_matrix,train=False)#batch_word_emd,
                f1, p, r = metrics.get_evaluate_fpr(logits, labels)
                total_f1_ += f1
                total_precision_ += p
                total_recall_ += r

            avg_f1 = total_f1_ / (len(test_dataloader))
            avg_precision = total_precision_ /(len(test_dataloader))
            avg_recall = total_recall_ /(len(test_dataloader))
            logger.info("EPOCH:%d\t EVAL_F1:%f\tPrecision:%f\tRecall:%f\t"%(eo, avg_f1,avg_precision,avg_recall))
            if avg_f1 > max_f:
                torch.save(model.state_dict(), './outputs/extract-ernie-gram_best_TEST_EP_L{}.pth'.format(eo))
                max_f = avg_f1
            # print('-------------------------max_f=',max_f,avg_precision,avg_recall)
            logger.info("-------------------------max_f=%f"%max_f)
            model.train()




            




    
    # read_train_data(args,tokenizer)
if __name__=='__main__':
    main()
