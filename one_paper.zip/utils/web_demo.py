# from  gradio import gr
import gradio as gr
import torch
import argparse
import numpy as np
from transformers import AutoModelForSequenceClassification, AutoTokenizer,BertConfig
from model import SpanExtractAndClassification

def parse_args():
    parser = argparse.ArgumentParser(description='Start Web Demo')
    parser.add_argument('--device', default='cuda', type=str, help='cpu or cuda')
    parser.add_argument('--model_name', default='/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/ernie-gram', type=str,
                        help='huggingface transformer model name')
    parser.add_argument('--model_path', default='/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/outputs/extract-ernie-gram_best_TEST_EP_L42.pth')
    parser.add_argument('--num_labels', default=6, type=int, help='fine-tune num labels')

    args = parser.parse_args()
    return args

class Runer():
    def __init__(self, label, device,model_name, model_path, *args, **kwargs):
        self.device = device
        # self.label = label
        self.model_name = model_name
        self.num_labels = len(label.keys())
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = self.build_model(model_name, model_path, self.num_labels)
        self.ent2id, self.id2ent = {"负向情感": 0, "中性情感": 1, "负向情感": 2}, {}
        # self.label_format = gr.outputs.Label()


    def build_model(self, model_name, model_path, num_labels):
        config = BertConfig.from_pretrained(model_name)
        model = SpanExtractAndClassification(config)
        model.load_state_dict(torch.load(model_path, map_location='cuda:1'))
        # model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)
        # print(f'Loading checkpoint: {model_path} ...')
        # checkpoint = torch.load(model_path, map_location='cpu')
        # missing_keys, unexpected_keys = model.load_state_dict(checkpoint['state_dict'], strict=True)
        # print(f'missing_keys: {missing_keys}\n'
        #       f'===================================================================\n')
        # print(f'unexpected_keys: {unexpected_keys}\n'
        #       f'===================================================================\n')
        model.eval()
        model.to(self.device)
        return model
    def infer(self, input):
        
        token2char_span_mapping = self.tokenizer(input, return_offsets_mapping=True, max_length=50)["offset_mapping"]
        new_span, entities= [], []
        aspect = []
        
        for k, v in self.ent2id.items(): self.id2ent[v] = k
        for i in token2char_span_mapping:
            if i[0] == i[1]:
                new_span.append([])
            else:
                if i[0] + 1 == i[1]:
                    new_span.append([i[0]])
                else:
                    new_span.append([i[0], i[-1] - 1])

        encoder_txt = self.tokenizer.encode_plus(input, max_length=50)
        input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(self.device)
        token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(self.device)
        attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(self.device)
        scores = self.model(input_ids, attention_mask, token_type_ids)[0].data.cpu().numpy()
        # print(scores)
        scores[:, [0, -1]] -= np.inf
        # print(scores)
        scores[:, :, [0, -1]] -= np.inf
        # print(scores)
        # print(*np.where(scores > 0))
        for l, start, end in zip(*np.where(scores > 0)):
            # print(l, start, end)
            # print(new_span[start][0])
            entities.append({"start_idx":new_span[start][0], "end_idx":new_span[end][-1], "type":self.id2ent[l]})
            # aspect.append({"start_idx":new_span[start][0], "end_idx":new_span[end][-1]})
        a=[]
        for i in entities:
            a.append(input[i["start_idx"]:i["end_idx"]+1])
        return str(f"方面词为:{a}"+"\n"+f"方面词边界和情感极性:{entities}")



        # token = self.tokenizer(input, padding='max_length', truncation=True, max_length=140)
        # input_ids = torch.tensor(token['input_ids'], device=self.device).unsqueeze(0)
        # with torch.no_grad():
        #     output = self.model(input_ids)
        # pred = torch.nn.functional.softmax(output.logits).detach().cpu().numpy()[0]
        # return {self.label[i]: float(pred[i]) for i in range(self.num_labels)}

    def run(self):
        example=[['色彩还原真实'],['感觉它的液晶屏用起来不是很爽'],['变速器输入和输出轴承等的滚珠和滚珠架非正常磨损严重'],['此机最大的问题便是触摸键太灵敏了'],['音质方面是差了点'],['位于屏幕下方的上网键很碍手'],['打开包装香气四溢，汤色透彻'],['茶汤色泽偏黄偏深，味道很淡'],['肉多核薄，皮薄易剥，水分充足感觉满满的维生素啊每个都很新鲜'],['个头很小，味道很难吃，果肉很不满意'],['花真的很新鲜,包装完好无损,是我想要的那种效果,花苞多,开的颜色也很正'],['花朵的颜色暗淡无光、并不美观']]
        iface = gr.Interface(fn=self.infer, inputs='text', outputs="text", examples=example)
        iface.launch(server_name='0.0.0.0', server_port=7860)



if __name__ == '__main__':
    args = vars(parse_args())
    args['label'] = {0: 'happy', 1: 'angry', 2: 'sad', 3: 'fear', 4: 'surprise', 5: 'neutral'}
    runer = Runer(**args)
    runer.run()
