# -*- coding: utf-8 -*-
"""
@Auth: Xhw
"""
from transformers import BertModel, BertTokenizerFast,BertConfig
# from models.GlobalPointer import EffiGlobalPointer as GlobalPointer
from model import SpanExtractAndClassification
import json
import torch
import numpy as np
from tqdm import  tqdm

bert_model_path = '/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/ernie-gram' #your RoBert_large path

save_model_path = '/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/outputs/extract-ernie-gram_best_TEST_EP_L42.pth' #67.94%
device = torch.device("cuda:1")

max_len = 50
ent2id, id2ent = {"NEG": 0, "NEU": 1, "POS": 2}, {}
for k, v in ent2id.items(): id2ent[v] = k

# device = torch.device("cuda:1")
tokenizer = BertTokenizerFast.from_pretrained(bert_model_path)
config = BertConfig.from_pretrained(bert_model_path)
model = SpanExtractAndClassification(config)
model.to(device)
# encoder =BertModel.from_pretrained(bert_model_path)
# model = GlobalPointer(encoder, 3 , 64).to(device)
model.load_state_dict(torch.load(save_model_path, map_location='cuda:1'))
model.eval()


def NER_RELATION(text, tokenizer, ner_model,  max_len=max_len):
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=max_len)["offset_mapping"]
    new_span, entities= [], []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])

    encoder_txt = tokenizer.encode_plus(text, max_length=max_len)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    scores = ner_model(input_ids, attention_mask, token_type_ids)[0].data.cpu().numpy()
    # print(scores)
    scores[:, [0, -1]] -= np.inf
    # print(scores)
    scores[:, :, [0, -1]] -= np.inf
    # print(scores)
    # print(*np.where(scores > 0))
    for l, start, end in zip(*np.where(scores > 0)):
        # print(l, start, end)
        # print(new_span[start][0])
        entities.append({"start_idx":new_span[start][0], "end_idx":new_span[end][-1], "type":id2ent[l]})

    return {"text":text, "entities":entities}

if __name__ == '__main__':
    all_ = []
    for d in tqdm(json.load(open('/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/test.txt'))):
        # print(d)
        a = NER_RELATION(d["text"], tokenizer= tokenizer, ner_model=model)
        # print(a)
        all_.append(a)
    # print("################################")
    json.dump(
        all_,
        open('./CMeEE_test.json', 'w'),
        indent=4,
        ensure_ascii=False
    )