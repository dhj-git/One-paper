from transformers import BertPreTrainedModel,BertModel
import torch.nn as nn
import numpy as np
from GCN import DiGCNLayerAtt
from GraphConvolution import GraphConvolution
import math
import torch
import torch.nn.functional as F
torch.set_printoptions(profile="full")
class GRU(nn.Module):
    # customized GRU with layer normalization
    def __init__(self, input_size, hidden_size, bidirectional=True):
        """

        :param input_size:
        :param hidden_size:
        :param bidirectional:
        """
        super(GRU, self).__init__()
        self.input_size = input_size
        if bidirectional:
            self.hidden_size = hidden_size // 2
        else:
            self.hidden_size = hidden_size
        self.bidirectional = bidirectional
        self.Wxrz = nn.Linear(in_features=self.input_size, out_features=2*self.hidden_size, bias=True)
        self.Whrz = nn.Linear(in_features=self.hidden_size, out_features=2*self.hidden_size, bias=True)
        self.Wxn = nn.Linear(in_features=self.input_size, out_features=self.hidden_size, bias=True)
        self.Whn = nn.Linear(in_features=self.hidden_size, out_features=self.hidden_size, bias=True)
        self.LNx1 = nn.LayerNorm(2*self.hidden_size)
        self.LNh1 = nn.LayerNorm(2*self.hidden_size)
        self.LNx2 = nn.LayerNorm(self.hidden_size)
        self.LNh2 = nn.LayerNorm(self.hidden_size)

    def forward(self, x):
        """

        :param x: input tensor, shape: (batch_size, seq_len, input_size)
        :return:
        """
        def recurrence(xt, htm1):
            """

            :param xt: current input
            :param htm1: previous hidden state
            :return:
            """
            gates_rz = torch.sigmoid(self.LNx1(self.Wxrz(xt)) + self.LNh1(self.Whrz(htm1)))
            rt, zt = gates_rz.chunk(2, 1)
            nt = torch.tanh(self.LNx2(self.Wxn(xt))+rt*self.LNh2(self.Whn(htm1)))
            ht = (1.0-zt) * nt + zt * htm1
            return ht

        steps = range(x.size(1))
        bs = x.size(0)
        hidden = self.init_hidden(bs)
        # shape: (seq_len, bsz, input_size)
        input = x.transpose(0, 1)
        output = []
        for t in steps:
            hidden = recurrence(input[t], hidden)
            output.append(hidden)
        # shape: (bsz, seq_len, input_size)
        output = torch.stack(output, 0).transpose(0, 1)

        if self.bidirectional:
            output_b = []
            hidden_b = self.init_hidden(bs)
            for t in steps[::-1]:
                hidden_b = recurrence(input[t], hidden_b)
                output_b.append(hidden_b)
            output_b = output_b[::-1]
            output_b = torch.stack(output_b, 0).transpose(0, 1)
            output = torch.cat([output, output_b], dim=-1)
        return output, None

    def init_hidden(self, bs):
        h_0 = torch.zeros(bs, self.hidden_size).cuda()
        return h_0

def multilabel_categorical_crossentropy(y_pred, y_true):
    y_pred = (1 - 2 * y_true) * y_pred  # -1 -> pos classes, 1 -> neg classes
    y_pred_neg = y_pred - y_true * 1e12  # mask the pred outputs of pos classes
    y_pred_pos = y_pred - (1 - y_true) * 1e12 # mask the pred outputs of neg classes
    zeros = torch.zeros_like(y_pred[..., :1])
    y_pred_neg = torch.cat([y_pred_neg, zeros], dim=-1)
    y_pred_pos = torch.cat([y_pred_pos, zeros], dim=-1)
    neg_loss = torch.logsumexp(y_pred_neg, dim=-1)
    pos_loss = torch.logsumexp(y_pred_pos, dim=-1)
    return (neg_loss + pos_loss).mean()

def loss_fun(y_true, y_pred):
    """
    y_true:(batch_size, ent_type_size, seq_len, seq_len)
    y_pred:(batch_size, ent_type_size, seq_len, seq_len)
    """
    batch_size, ent_type_size = y_pred.shape[:2]
    y_true = y_true.reshape(batch_size * ent_type_size, -1)
    y_pred = y_pred.reshape(batch_size * ent_type_size, -1)
    loss = multilabel_categorical_crossentropy(y_true, y_pred)
    return loss

class MetricsCalculator(object):
    def __init__(self):
        super().__init__()

    def get_sample_f1(self, y_pred, y_true):
        y_pred = torch.gt(y_pred, 0).float()
        return 2 * torch.sum(y_true * y_pred) / torch.sum(y_true + y_pred)

    def get_sample_precision(self, y_pred, y_true):
        y_pred = torch.gt(y_pred, 0).float()
        return torch.sum(y_pred[y_true == 1]) / (y_pred.sum() + 1)

    def get_evaluate_fpr(self, y_pred, y_true):
        X, Y, Z = 1e-10, 1e-10, 1e-10
        y_pred = y_pred.data.cpu().numpy()
        y_true = y_true.data.cpu().numpy()
        pred = []
        true = []
        for b, l, start, end in zip(*np.where(y_pred > 0)):
            # pred.append((b, l, start, end))
            pred.append((b,l, start, end))
        for b, l, start, end in zip(*np.where(y_true > 0)):
            # true.append((b, l, start, end))
            true.append((b,l, start, end))
        # print(true)
        R = set(pred)
        T = set(true)
        X = len(R & T) #&	按位与运算符：参与运算的两个值,如果两个相应位都为1,则该位的结果为1,否则为0
        Y = len(R)
        Z = len(T)
        if Y==0 or Z==0:
            return 0,0,0
        f1, precision, recall = 2 * X / (Y + Z), X / Y, X / Z
        return f1, precision, recall
def get_simcse_loss(once_emb, twice_emb, t=0.05):
    """用于无监督SimCSE训练的loss

    :param once_emb: [batch_size, emb_dim], 第一次dropout后的句子编码
    :param twice_emb: [batch_size, emb_dim], 第二次dropout后的句子编码
    :param t: 温度系数
    """
    # 构造标签，[1,0,3,2,5,4,...]
    batch_size = once_emb.size(0)
    y_true = torch.cat([torch.arange(1, batch_size*2, step=2, dtype=torch.long).unsqueeze(1), torch.arange(0, batch_size*2, step=2, dtype=torch.long).unsqueeze(1)], dim=1).reshape([batch_size*2,]).to(once_emb.device)

    batch_emb = torch.cat([once_emb, twice_emb], dim=1).reshape(batch_size*2, -1)  # [a1,a2,b1,b2,...]
    # 计算score和loss
    # L2标准化
    norm_emb = F.normalize(batch_emb, dim=1, p=2)
    # 计算一个batch内样本之间的相似度
    sim_score = torch.matmul(norm_emb, norm_emb.transpose(0,1))
    # mask掉和自身的相似度
    sim_score = sim_score - torch.eye(batch_size*2, device=once_emb.device) * 1e12
    sim_score = sim_score / t
    loss = F.cross_entropy(sim_score, y_true)
    return loss
class SinusoidalPositionEmbedding(nn.Module):
    """定义Sin-Cos位置Embedding
    """
    def __init__(
        self, output_dim, merge_mode='add', custom_position_ids=False):
        super(SinusoidalPositionEmbedding, self).__init__()
        self.output_dim = output_dim
        self.merge_mode = merge_mode
        self.custom_position_ids = custom_position_ids

    def forward(self, inputs):
        if self.custom_position_ids:
            seq_len = inputs.shape[1]
            inputs,position_ids = inputs
            position_ids = position_ids.type(torch.float)
        else:
            input_shape = inputs.shape
            batch_size, seq_len = input_shape[0], input_shape[1]
            position_ids = torch.arange(seq_len).type(torch.float)[None]
        indices = torch.arange(self.output_dim // 2).type(torch.float)
        indices = torch.pow(10000.0, -2 * indices / self.output_dim)
        embeddings = torch.einsum('bn,d->bnd', position_ids, indices)
        embeddings = torch.stack([torch.sin(embeddings), torch.cos(embeddings)], dim=-1)
        embeddings = torch.reshape(embeddings, (-1, seq_len, self.output_dim))
        if self.merge_mode == 'add':
            return inputs + embeddings.to(inputs.device)
        elif self.merge_mode == 'mul':
            return inputs * (embeddings + 1.0).to(inputs.device)
        elif self.merge_mode == 'zero':
            return embeddings.to(inputs.device)
# config.lstm_hidden_size=768,
# config.dropout=0.5,
# config.ent_type_size=3,
# config.inner_dim=64
class SpanExtractAndClassification(BertPreTrainedModel):
    def __init__(self, config, RoPE=True):
        super(SpanExtractAndClassification, self).__init__(config)
        self.bert = BertModel(config)
        self.ent_type_size = 3
        self.inner_dim = 64
        self.hidden_size = config.hidden_size
        self.RoPE = RoPE
        self.dense_1 = nn.Linear(self.hidden_size, self.inner_dim * 2)
        self.dense_2 = nn.Linear(self.hidden_size, self.ent_type_size * 2) #原版的dense2是(inner_dim * 2, ent_type_size * 2)

        # self.ian = INTER_AEN()
        self.dense_3 = nn.Linear(256,self.hidden_size)
        self.dropout = nn.Dropout(0.5)
        self.layer_number =1
        # self.GCNLayers = nn.ModuleList(([DiGCNLayerAtt(config.hidden_size)
                                        #  for _ in range(self.layer_number)]))
        # self.GC = GraphConvolution(self.hidden_size,self.hidden_size)
        self.temper = self.hidden_size ** 0.5
        self.softmax = nn.Softmax(dim=-1)
        # self.GRU = GRU(self.hidden_size, self.hidden_size, bidirectional=True)

    def sequence_masking(self, x, mask, value='-inf', axis=None):
        if mask is None:
            return x
        else:
            if value == '-inf':
                value = -1e12
            elif value == 'inf':
                value = 1e12
            assert axis > 0, 'axis must be greater than 0'
            for _ in range(axis - 1):
                mask = torch.unsqueeze(mask, 1)
            for _ in range(x.ndim - mask.ndim):
                mask = torch.unsqueeze(mask, mask.ndim)
            return x * mask + value * (1 - mask)
    def add_mask_tril(self, logits, mask):
        if mask.dtype != logits.dtype:
            mask = mask.type(logits.dtype)
        logits = self.sequence_masking(logits, mask, '-inf', logits.ndim - 2)
        logits = self.sequence_masking(logits, mask, '-inf', logits.ndim - 1)
        # 排除下三角
        mask = torch.tril(torch.ones_like(logits), diagonal=-1)
        logits = logits - mask * 1e12
        return logits
    def get_att(self, matrix_1, matrix_2, adjacency_matrix):
        u = torch.matmul(matrix_1.float(), matrix_2.permute(0, 2, 1).float()) / self.temper
        attention_scores = self.softmax(u)
        delta_exp_u = torch.mul(attention_scores, adjacency_matrix)
        sum_delta_exp_u = torch.stack([torch.sum(delta_exp_u, 2)] * delta_exp_u.shape[2], 2)
        attention = torch.div(delta_exp_u, sum_delta_exp_u + 1e-10).type_as(matrix_1)
        return attention
    # def transform(self,matrix):
    #     n ,m,k,l=matrix.shape[0],matrix.shape[1],matrix.shape[2],matrix.shape[3] 
    #     new_matrix = matrix.clone().detach().cpu().numpy()
    #     for i in  range(n):
    #         for j in range(m):
    #             for x in range(k):
    #                 for y in range(l):
    #                     if math.fabs(y-x)>20:
    #                         new_matrix[i][j][x][y] = 0
    #     return torch.from_numpy(new_matrix).to(matrix.device).requires_grad_(True)


    def forward(self, input_ids, attention_mask, token_type_ids,adjacency_matrix=None,train=None,labels=None):#batch_word_emd,
        # self.device = input_ids.device
        
        context_outputs = self.bert(input_ids, attention_mask, token_type_ids)
        context_outputs1 = self.bert(input_ids, attention_mask, token_type_ids)
        last_hidden_state1 = context_outputs1.last_hidden_state
        last_hidden_state = context_outputs.last_hidden_state
        simcse_loss = get_simcse_loss(last_hidden_state, last_hidden_state1)
        # batch_word_emd = batch_word_emd.to(dtype=last_hidden_state.dtype)
        # print(batch_word_emd.shape)
        # batch_word_emd = self.dense_3(batch_word_emd).squeeze(dim=1)
        # print(batch_word_emd.shape)
        # last_hidden_state = batch_word_emd + last_hidden_state 
        # print(last_hidden_state.shape)
        outputs = self.dense_1(last_hidden_state) #(batch,seq,128)
        
        qw, kw = outputs[...,::2], outputs[..., 1::2] #从0,1开始间隔为2
        if self.RoPE:
            pos = SinusoidalPositionEmbedding(self.inner_dim, 'zero')(outputs)
            cos_pos = pos[..., 1::2].repeat_interleave(2, dim=-1)
            sin_pos = pos[..., ::2].repeat_interleave(2, dim=-1)
            qw2 = torch.stack([-qw[..., 1::2], qw[..., ::2]], 3)
            qw2 = torch.reshape(qw2, qw.shape)
            qw = qw * cos_pos + qw2 * sin_pos
            # print(qw.shape) (32,200,64)
            kw2 = torch.stack([-kw[..., 1::2], kw[..., ::2]], 3)
            kw2 = torch.reshape(kw2, kw.shape)
            kw = kw * cos_pos + kw2 * sin_pos
        logits = torch.einsum('bmd,bnd->bmn', qw, kw) / self.inner_dim**0.5
        ####GCN卷积
        # attention = self.get_att(last_hidden_state,last_hidden_state,adjacency_matrix)
        # # print(attention.shape)
        # attention_probs = self.softmax(attention) #归一化
        # f = open("attention.txt",'a')
        # print(attention,file =f)
        # print("*****************")
        # logit_att = torch.mul(attention_probs,logits) #[32,120,120]
        # logits = logit_att
        # print(logits.copy())
        # print(context_layer.shape)
        #####
        # print(logits.shape)#[32,120,120]
        bias = torch.einsum('bnh->bhn', self.dense_2(last_hidden_state)) / 2
        # print(bias.shape) #[32,6,120]
        logits = logits[:, None] + bias[:, ::2, None] + bias[:, 1::2, :, None] #logits[:, None] 增加一个维度[32,3,120,120]
        # logits = self.transform(logits)
        # print(logits.shape)
        
        logits = self.add_mask_tril(logits, mask=attention_mask)
        if train:
            loss = loss_fun(logits, labels)
            return loss,logits #+0.5*simcse_loss，0.5*
        else:
            return logits
