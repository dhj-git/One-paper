# -*- coding: utf-8 -*-
"""
@Auth: Xhw
"""
from transformers import BertModel, BertTokenizerFast,AutoConfig,AutoTokenizer
from model import SpanExtractAndClassification
import json
import torch
import numpy as np
from tqdm import  tqdm

bert_model_path = '/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/ernie-gram' #your RoBert_large path

save_model_path = '/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/outputs/extract-ernie-gram_best_TEST_EP_L17.pth' #67.94%
device = torch.device("cuda:2")

max_len = 200
ent2id, id2ent = {"NEG": 0, "NEU": 1, "POS": 2}, {}
for k, v in ent2id.items(): id2ent[v] = k

config = AutoConfig.from_pretrained(bert_model_path)
tokenizer = AutoTokenizer.from_pretrained(bert_model_path)

model = SpanExtractAndClassification.from_pretrained(bert_model_path)
model.load_state_dict(torch.load(save_model_path, map_location='cuda:2'))
model.eval()

def NER_RELATION(text, tokenizer, ner_model,  max_len=max_len):
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=max_len)["offset_mapping"]
    new_span, entities= [], []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])

    encoder_txt = tokenizer.encode_plus(text, max_length=max_len)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    scores = model(input_ids, attention_mask, token_type_ids)[0].data.cpu().numpy()
    scores[:, [0, -1]] -= np.inf
    scores[:, :, [0, -1]] -= np.inf
    for l, start, end in zip(*np.where(scores > 0)):
        entities.append({"start_idx":new_span[start][0], "end_idx":new_span[end][-1], "type":id2ent[l]})

    return {"text":text, "entities":entities}

if __name__ == '__main__':
    all_ = []
    for d in tqdm(json.load(open('./data/1.txt'))):
        print(d)
        all_.append(NER_RELATION(d["text"], tokenizer= tokenizer, ner_model=model))
    json.dump(
        all_,
        open('./outputs/ASPE_test.json', 'w'),
        indent=4,
        ensure_ascii=False
    )