import json
from os import path
import argparse
from tqdm import tqdm
import re
from collections import defaultdict
from stanfordcorenlp import StanfordCoreNLP
import logging
import numpy as np

def stanfordNLPProcess(text,max_sent_len):
    ###'我喜欢中国的历史文化'
    FULL_MODEL = '/home/sys1/Dong/DGSA/data/stanford-corenlp-full-2018-02-27'
    nlp = StanfordCoreNLP(FULL_MODEL, lang='zh',quiet=False,logging_level=logging.DEBUG) 
    dep_outputs = nlp.dependency_parse(text)  ##[('ROOT', 0, 2), ('nsubj', 2, 1), ('nmod:assmod', 6, 3), ('case', 3, 4), ('compound:nn', 6, 5), ('dobj', 2, 6)]
    tokens = list(text)
    root_index=[]
    for i in range(len(dep_outputs)):
        if dep_outputs[i][0]=='ROOT':
            root_index.append(i)
    
    '''修改依存关系三元组，针对多句话情况'''
    new_dep_outputs=[]
    for i in range(len(dep_outputs)):
        for index in root_index:
            if i+1>index:
                tag=index

        if dep_outputs[i][0]=='ROOT':	
            dep_output=(dep_outputs[i][0],dep_outputs[i][1],dep_outputs[i][2]+tag)
        else:
            dep_output = (dep_outputs[i][0], dep_outputs[i][1] + tag, dep_outputs[i][2] + tag)
        new_dep_outputs.append(dep_output)
    # print(new_dep_outputs) 
    #求解headlist
    head_list = []
    for i in range(len(tokens)):
        for dep_output in new_dep_outputs:
            if dep_output[-1] == i + 1:
                head_list.append(int(dep_output[1]))
    #建立邻接矩阵
    adjacency_matrix = np.zeros((max_sent_len, max_sent_len), dtype=np.float32)
    for i in range(len(head_list)):
        j=head_list[i]
        if j!=0:
            adjacency_matrix[i,j-1]=1
            adjacency_matrix[j-1,i]=1
    return adjacency_matrix

