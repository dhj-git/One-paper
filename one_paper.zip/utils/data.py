import numpy as np
import pyhanlp
from gensim.models import Word2Vec
from torch.utils.data import Dataset
import torch
# from stanfordcorenlp import StanfordCoreNLP


# FULL_MODEL = '/home/sys1/Dong/DGSA/data/stanford-corenlp-full-2018-02-27'
# nlp = StanfordCoreNLP(FULL_MODEL, lang='zh') 

# # # 数据处理部分
# word2vec = Word2Vec.load('/home/ynau/labcode/Dong/Stage_One_Paper/AAEfficient-GlobalPointer-torch/word2vec_baike')
# id2word = {i+1:j for i,j in enumerate(word2vec.wv.index_to_key)}
# word2id = {j:i for i,j in id2word.items()}
# word2vec = word2vec.wv.vectors
# word_size = word2vec.shape[1]
# word2vec = np.concatenate([np.zeros((1, word_size)), word2vec])

# def tokenize_word(s):
#     return [i.word for i in pyhanlp.HanLP.segment(s)]
# def seq_padding(X, padding=0):

#     #L = [len(x) for x in X]
#     ML = 120
#     return np.array([np.concatenate([X, [padding] * (ML - len(X))])])

# #     return np.array(lis)
# def sent2vec(S):
#     """S格式：[w1, w2]
#     """
#     V = []
#     for w in S:
#         for _ in w:
#             V.append(word2id.get(w, 0))
#             # print(word2id.get(w, 0)) #['你', '是不是', '一个', '人']得到每一个词重复id：71,5439,5439,5439,47,47,30
#     # print(V)
#     V = seq_padding(V)
#     # print(V)
#     V = word2vec[V]
#     # print(len(V[0][0]))
#     return V
####


class SemEvalExample(object):
    def __init__(self,
                 example_id,
                 new_polarities=None):
        self.example_id = example_id
        self.polarities = new_polarities

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        s = ""
        if self.polarities:
            s += ", polarities: {}".format(self.polarities)
        return s
class InputFeatures(object):
    def __init__(self,input_ids,segment_ids,attention_mask,labels):
        self.input_ids = input_ids
        self.segment_ids = segment_ids
        self.attention_mask = attention_mask
        self.labels = labels
        

def pos2term(words, starts, ends):
    term_texts = []
    for start, end in zip(starts, ends):
        term_texts.append(' '.join(words[start:end+1]))
    return term_texts

def ts2polarity(words, ts_tag_sequence, starts, ends):
    polarities = []
    for start, end in zip(starts, ends):
        cur_ts_tag = ts_tag_sequence[start]
        cur_pos, cur_sentiment = cur_ts_tag.split('-')
        assert cur_pos == 'T'
        prev_sentiment = cur_sentiment
        if start < end:
            for idx in range(start, end + 1):
                cur_ts_tag = ts_tag_sequence[idx]
                cur_pos, cur_sentiment = cur_ts_tag.split('-')
                assert cur_pos == 'T'
                assert cur_sentiment == prev_sentiment, (words, ts_tag_sequence, start, end)
                prev_sentiment = cur_sentiment
        polarities.append(cur_sentiment)
    return polarities
def ts2start_end(ts_tag_sequence):
    starts, ends = [], []
    n_tag = len(ts_tag_sequence)
    prev_pos, prev_sentiment = '$$$', '$$$'
    tag_on = False
    for i in range(n_tag):
        cur_ts_tag = ts_tag_sequence[i]
        if cur_ts_tag != 'O':
            cur_pos, cur_sentiment = cur_ts_tag.split('-')
        else:
            cur_pos, cur_sentiment = 'O', '$$$'
        assert cur_pos == 'O' or cur_pos == 'T'
        if cur_pos == 'T':
            if prev_pos != 'T':
                # cur tag is at the beginning of the opinion target
                starts.append(i)
                tag_on = True
            else:
                if cur_sentiment != prev_sentiment:
                    # prev sentiment is not equal to current sentiment
                    ends.append(i - 1)
                    starts.append(i)
                    tag_on = True
        else:
            if prev_pos == 'T':
                ends.append(i - 1)
                tag_on = False
        prev_pos = cur_pos
        prev_sentiment = cur_sentiment
    if tag_on:
        ends.append(n_tag-1)
    assert len(starts) == len(ends), (len(starts), len(ends), ts_tag_sequence)
    return starts, ends
label2id = {"NEG": 0, "NEU": 1, "POS": 2} #CMeEE 原有八类
id2label ={}
for k, v in label2id.items(): id2label[v] = k
ent2id={"NEG": 0, "NEU": 1, "POS": 2}
# ent2id={"ASP":0}
id2ent = {}
for k, v in ent2id.items(): id2ent[v] = k
def load_data(path):
    """
    data = ['寸万像素的超级晶彩屏视角非常宽', (8, 11, 'POS'),()],...]     
    """
    data = []
    cat = set()
    dataset = []
    with open(path, encoding='UTF-8') as fp:
        for line in fp:
            record = {}
            tag_string = line.strip()
            if len(line.strip().split('####'))==2:
                sent, tag_string = line.strip().split('####')
            else:
                tag_string = line.strip()
            word_tag_pairs = tag_string.split(' ')
            ts_tags = []
            ote_tags = []
            # word sequence
            words = []
            for item in word_tag_pairs:
                # valid label is: O, T-POS, T-NEG, T-NEU
                eles = item.split('=')
                if len(eles) == 2:
                    word, tag = eles
                elif len(eles) > 2:
                    tag = eles[-1]
                    word = (len(eles) - 2) * "="
                words.append(word.lower())
                #print(words)
                
                if tag == 'O':
                    ote_tags.append('O')
                    ts_tags.append('O')
                elif tag == 'T-POS':
                    ote_tags.append('T')
                    ts_tags.append('T-POS')
                elif tag == 'T-NEG':
                    ote_tags.append('T')
                    ts_tags.append('T-NEG')
                elif tag == 'T-NEU':
                    ote_tags.append('T')
                    ts_tags.append('T-NEU')
                else:
                    raise Exception('Invalid tag %s!!!' % tag)
            # print(words)
            record['words'] = words.copy()
            record['ote_raw_tags'] = ote_tags.copy()
            record['ts_raw_tags'] = ts_tags.copy()
            dataset.append(record)
    examples = []
    n_records = len(dataset)
    for i in range(n_records):
        new_polarities = []
        
        words = dataset[i]['words']
        # print(words)
        ts_tags = dataset[i]['ts_raw_tags']
        starts, ends = ts2start_end(ts_tags)
        polarities = ts2polarity(words, ts_tags, starts, ends)
        for polarity1 in polarities:
                if polarity1 == 'POS':
                    new_polarities.append('POS')
                elif polarity1 == 'NEG':
                    new_polarities.append('NEG')
                elif polarity1 == 'NEU':
                    new_polarities.append('NEU')
        example = SemEvalExample(str(i),new_polarities)
        examples.append(example)
        ele = []
        context=''.join(words)#句子
        data.append([context])
        for i,j,m in zip(starts,ends,polarities):

            
            # ele.append((i,j,k))
            # k='ASP'
            cat.add(k)
            # print(ele)
            # print(cat)
            data[-1].append((i,j,ent2id[k]))
            #print(data)
    # f = open("data.txt",'a')
    # print("*******************************88")
    # print(data,file=f)
    # f.close 
    # filename = "data.json"
    # with open(filename, 'w') as file_obj:
    #     json.dump(data, file_obj)
    # print("**************************")
    # print(len(data))
    # polaritylabel = []
    # labelmask=[]
    # for (example_index, example) in enumerate(examples):
    #     polarity_labels = [label2id[polarity] for polarity in example.polarities]
    #     # print(polarity_labels)
    #     label_masks = [1] * len(polarity_labels)
    #     polaritylabel.append(polarity_labels)
    #     labelmask.append(label_masks)
    # assert len(polaritylabel) == len(labelmask)
    # print(data)
    return data


class EntDataset(Dataset):
    def __init__(self, data, tokenizer, max_len,f,istrain=True):
        self.data = data
        self.tokenizer = tokenizer
        self.istrain = istrain
        self.max_len = max_len
        self.f = f
        self.i = 0

    def __len__(self):
        return len(self.data)

    def encoder(self, item):
        if self.istrain:
            if self.i >=len(self.f):
                self.i = 0
            text = item[0]

            # seg = tokenize_word(text)
            
            # # print(seg_word)
            # # print(text)
            # word_emd = sent2vec(seg)
            # print(word_emd)
            
            # print('self.i',self.i)
            dep_out = self.f[self.i]
            # print(self.i)
            # print(dep_out)
            # dep_out = nlp.dependency_parse(text)
            root_index=[]
            for i in range(len(dep_out)):
                if dep_out[i][0]=='ROOT':
                    root_index.append(i)
            new_dep_outputs=[]
            for i in range(len(dep_out)):
                for index in root_index:
                    if i+1>index:
                        tag=index
                if dep_out[i][0]=='ROOT':	
                    dep_output=(dep_out[i][0],dep_out[i][1],dep_out[i][2]+tag)
                else:
                    dep_output = (dep_out[i][0], dep_out[i][1] + tag, dep_out[i][2] + tag)
                new_dep_outputs.append(dep_output)
                    #求解headlist
            tokens = list(text)
            head_list = []
            for i in range(len(tokens)):
                for dep_output in new_dep_outputs:
                    if dep_output[-1] == i + 1:
                        head_list.append(int(dep_output[1]))
            #建立邻接矩阵
            adjacency_matrix = np.zeros((self.max_len, self.max_len), dtype=np.float32)
            for i in range(len(head_list)):
                j=head_list[i]
                if j!=0:
                    adjacency_matrix[i,i] = 1
                    adjacency_matrix[i+1,j]=1
                    adjacency_matrix[j,i+1]=1
            if self.i <len(self.f):
                self.i = self.i+1
            else:
                self.i = 0
            # print(text)
            token2char_span_mapping = self.tokenizer(text, return_offsets_mapping=True, max_length=self.max_len, truncation=True)["offset_mapping"]
            # print(token2char_span_mapping)
            # print(token2char_span_mapping)
            start_mapping = {j[0]: i for i, j in enumerate(token2char_span_mapping) if j != (0, 0)}
            end_mapping = {j[-1] - 1: i for i, j in enumerate(token2char_span_mapping) if j != (0, 0)}
            #将raw_text的下标 与 token的start和end下标对应
            encoder_txt = self.tokenizer.encode_plus(text, padding='max_length',max_length=self.max_len, truncation=True)
            # print(encoder_txt)
            input_ids = encoder_txt["input_ids"]
            token_type_ids = encoder_txt["token_type_ids"]
            attention_mask = encoder_txt["attention_mask"]


            return text, start_mapping, end_mapping, input_ids, token_type_ids, attention_mask,adjacency_matrix#,word_emd
        else:
            #TODO 测试
            pass

    

    def collate(self, examples):
        raw_text_list, batch_input_ids, batch_attention_mask, batch_labels, batch_segment_ids = [], [], [], [], []
        batch_adjacency_matrix = []
        batch_word_emd = []
        batch_labels_bin = []
        for item in examples:
            # print(item)#['第一次在京东上买水果，感觉还不错，水果也挺新鲜的', (21, 22, 2)]
            raw_text, start_mapping, end_mapping, input_ids, token_type_ids, attention_mask,adjacency_matrix = self.encoder(item,)#,word_emd

            labels = np.zeros((len(ent2id), self.max_len, self.max_len))
            labels_binary = np.zeros((2, self.max_len, self.max_len))
            polarys = []
            for start, end, label  in item[1:]:
                if start in start_mapping and end in end_mapping:
                    start = start_mapping[start]
                    end = end_mapping[end]
                    labels[label, start, end] = 1

                    for end_ in range(start, end):
                        labels_binary[1, start, end_] = 1
                    labels_binary[1, start, end] = 1

            
            raw_text_list.append(raw_text)
            batch_input_ids.append(input_ids)
            batch_segment_ids.append(token_type_ids)
            batch_attention_mask.append(attention_mask)
            batch_labels.append(labels[:, :len(input_ids), :len(input_ids)])
            batch_adjacency_matrix.append(adjacency_matrix)
            # batch_word_emd.append(word_emd)
            
           

        batch_inputids = torch.tensor(batch_input_ids).long()
        batch_segmentids = torch.tensor(batch_segment_ids).long()
        batch_attentionmask = torch.tensor(batch_attention_mask).float()
        batch_labels = torch.tensor(batch_labels).long()
        batch_adjacency_matrix = torch.tensor(batch_adjacency_matrix).long()
        # batch_word_emd = torch.tensor(batch_word_emd)
        # print(batch_adjacency_matrix.shape)


        return raw_text_list, batch_inputids, batch_attentionmask, batch_segmentids, batch_labels,batch_adjacency_matrix#,batch_word_emd

    def __getitem__(self, index):
        #print(index)
        item = self.data[index]
        # print('item',index)
        return item
# if __name__ == "__main__":
#     tokenizer = AutoTokenizer.from_pretrained('/home/sys1/Dong/ABcode/ernie-1.0')

#     data = load_data('/home/sys1/Dong/SHUSHEN/Efficient-GlobalPointer-torch/data/dev.txt')
#     data_to_features(data,tokenizer,max_len=200)

